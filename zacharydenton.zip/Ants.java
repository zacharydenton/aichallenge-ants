import java.util.*;
import java.util.logging.*;

/**
 * Holds all game data and current game state.
 */
public class Ants {
	/** Maximum map size. */
	public static final int MAX_MAP_SIZE = 256;

	private final int loadTime;

	private final int turnTime;

	private final int rows;

	private final int cols;

	private final int turns;

	private final int viewRadius2;

	private final int attackRadius2;

	private final int spawnRadius2;

	private boolean[][] visionMatrix;
	private int[][] visionOffsets2;

	private long turnStartTime;

	private final Ilk map[][];

	private final Set<Tile> myAnts = new HashSet<Tile>();

	private final Set<Tile> enemyAnts = new HashSet<Tile>();

	private final Set<Tile> myHills = new HashSet<Tile>();

	private final Set<Tile> enemyHills = new HashSet<Tile>();

	private final Set<Tile> foodTiles = new HashSet<Tile>();

	private final Set<Order> orders = new HashSet<Order>();

	/**
	 * Creates new {@link Ants} object.
	 * 
	 * @param loadTime timeout for initializing and setting up the bot on turn 0
	 * @param turnTime timeout for a single game turn, starting with turn 1
	 * @param rows game map height
	 * @param cols game map width
	 * @param turns maximum number of turns the game will be played
	 * @param viewRadius2 squared view radius of each ant
	 * @param attackRadius2 squared attack radius of each ant
	 * @param spawnRadius2 squared spawn radius of each ant
	 */
	public Ants(int loadTime, int turnTime, int rows, int cols, int turns, int viewRadius2,
			int attackRadius2, int spawnRadius2) {
		this.loadTime = loadTime;
		this.turnTime = turnTime;
		this.rows = rows;
		this.cols = cols;
		this.turns = turns;
		this.viewRadius2 = viewRadius2;
		this.attackRadius2 = attackRadius2;
		this.spawnRadius2 = spawnRadius2;
		this.visionMatrix = null;
		this.visionOffsets2 = null;
		map = new Ilk[rows][cols];
		for (Ilk[] row : map) {
			Arrays.fill(row, Ilk.LAND);
		}
	}

	/**
	 * Returns timeout for initializing and setting up the bot on turn 0.
	 * 
	 * @return timeout for initializing and setting up the bot on turn 0
	 */
	public int getLoadTime() {
		return loadTime;
	}

	/**
	 * Returns timeout for a single game turn, starting with turn 1.
	 * 
	 * @return timeout for a single game turn, starting with turn 1
	 */
	public int getTurnTime() {
		return turnTime;
	}

	/**
	 * Returns game map height.
	 * 
	 * @return game map height
	 */
	public int getRows() {
		return rows;
	}

	/**
	 * Returns game map width.
	 * 
	 * @return game map width
	 */
	public int getCols() {
		return cols;
	}

	/**
	 * Returns maximum number of turns the game will be played.
	 * 
	 * @return maximum number of turns the game will be played
	 */
	public int getTurns() {
		return turns;
	}

	/**
	 * Returns squared view radius of each ant.
	 * 
	 * @return squared view radius of each ant
	 */
	public int getViewRadius2() {
		return viewRadius2;
	}

	/**
	 * Returns squared attack radius of each ant.
	 * 
	 * @return squared attack radius of each ant
	 */
	public int getAttackRadius2() {
		return attackRadius2;
	}

	/**
	 * Returns squared spawn radius of each ant.
	 * 
	 * @return squared spawn radius of each ant
	 */
	public int getSpawnRadius2() {
		return spawnRadius2;
	}

	/**
	 * Sets turn start time.
	 * 
	 * @param turnStartTime turn start time
	 */
	public void setTurnStartTime(long turnStartTime) {
		this.turnStartTime = turnStartTime;
	}

	/**
	 * Returns how much time the bot has still has to take its turn before timing out.
	 * 
	 * @return how much time the bot has still has to take its turn before timing out
	 */
	public int getTimeRemaining() {
		return turnTime - (int)(System.currentTimeMillis() - turnStartTime);
	}

	/**
	 * Returns ilk at the specified location.
	 * 
	 * @param tile location on the game map
	 * 
	 * @return ilk at the <cod>tile</code>
	 */
	public Ilk getIlk(Tile tile) {
		return map[tile.getRow()][tile.getCol()];
	}

	/**
	 * Sets ilk at the specified location.
	 * 
	 * @param tile location on the game map
	 * @param ilk ilk to be set at <code>tile</code>
	 */
	public void setIlk(Tile tile, Ilk ilk) {
		map[tile.getRow()][tile.getCol()] = ilk;
	}

	/**
	 * Returns ilk at the location in the specified direction from the specified location.
	 * 
	 * @param tile location on the game map
	 * @param direction direction to look up
	 * 
	 * @return ilk at the location in <code>direction</code> from <cod>tile</code>
	 */
	public Ilk getIlk(Tile tile, Aim direction) {
		Tile newTile = getTile(tile, direction);
		return map[newTile.getRow()][newTile.getCol()];
	}

	/**
	 * Returns location in the specified direction from the specified location.
	 * 
	 * @param tile location on the game map
	 * @param direction direction to look up
	 * 
	 * @return location in <code>direction</code> from <cod>tile</code>
	 */
	public Tile getTile(Tile tile, Aim direction) {
		int row = (tile.getRow() + direction.getRowDelta()) % rows;
		if (row < 0) {
			row += rows;
		}
		int col = (tile.getCol() + direction.getColDelta()) % cols;
		if (col < 0) {
			col += cols;
		}
		return new Tile(row, col);
	}

	/**
	 * Returns a set containing all my ants locations.
	 * 
	 * @return a set containing all my ants locations
	 */
	public Set<Tile> getMyAnts() {
		return myAnts;
	}

	/**
	 * Returns a set containing all enemy ants locations.
	 * 
	 * @return a set containing all enemy ants locations
	 */
	public Set<Tile> getEnemyAnts() {
		return enemyAnts;
	}

	/**
	 * Returns a set containing all my hills locations.
	 * 
	 * @return a set containing all my hills locations
	 */
	public Set<Tile> getMyHills() {
		return myHills;
	}

	/**
	 * Returns a set containing all enemy hills locations.
	 * 
	 * @return a set containing all enemy hills locations
	 */
	public Set<Tile> getEnemyHills() {
		return enemyHills;
	}

	/**
	 * Returns a set containing all food locations.
	 * 
	 * @return a set containing all food locations
	 */
	public Set<Tile> getFoodTiles() {
		return foodTiles;
	}

	/**
	 * Returns all orders sent so far.
	 * 
	 * @return all orders sent so far
	 */
	public Set<Order> getOrders() {
		return orders;
	}

	/**
	 * Calculates distance between two locations on the game map.
	 * 
	 * @param t1 one location on the game map
	 * @param t2 another location on the game map
	 * 
	 * @return distance between <code>t1</code> and <code>t2</code>
	 */
	public int getDistance(Tile t1, Tile t2) {
		int rowDelta = Math.abs(t1.getRow() - t2.getRow());
		int colDelta = Math.abs(t1.getCol() - t2.getCol());
		rowDelta = Math.min(rowDelta, rows - rowDelta);
		colDelta = Math.min(colDelta, cols - colDelta);
		return rowDelta * rowDelta + colDelta * colDelta;
	}

	/**
	 * Returns one or two orthogonal directions from one location to the another.
	 * 
	 * @param t1 one location on the game map
	 * @param t2 another location on the game map
	 * 
	 * @return orthogonal directions from <code>t1</code> to <code>t2</code>
	 */
	public List<Aim> getDirections(Tile t1, Tile t2) {
		List<Aim> directions = new ArrayList<Aim>();
		if (t1.getRow() < t2.getRow()) {
			if (t2.getRow() - t1.getRow() >= rows / 2) {
				directions.add(Aim.NORTH);
			} else {
				directions.add(Aim.SOUTH);
			}
		} else if (t1.getRow() > t2.getRow()) {
			if (t1.getRow() - t2.getRow() >= rows / 2) {
				directions.add(Aim.SOUTH);
			} else {
				directions.add(Aim.NORTH);
			}
		}
		if (t1.getCol() < t2.getCol()) {
			if (t2.getCol() - t1.getCol() >= cols / 2) {
				directions.add(Aim.WEST);
			} else {
				directions.add(Aim.EAST);
			}
		} else if (t1.getCol() > t2.getCol()) {
			if (t1.getCol() - t2.getCol() >= cols / 2) {
				directions.add(Aim.EAST);
			} else {
				directions.add(Aim.WEST);
			}
		}
		return directions;
	}

	/**
	 * Clears game state information about my ants locations.
	 */
	public void clearMyAnts() {
		myAnts.clear();
	}

	/**
	 * Clears game state information about enemy ants locations.
	 */
	public void clearEnemyAnts() {
		enemyAnts.clear();
	}

	/**
	 * Clears game state information about my hills locations.
	 */
	public void clearMyHills() {
		myHills.clear();
	}

	/**
	 * Clears game state information about enemy hills locations.
	 */
	public void clearEnemyHills() {
		enemyHills.clear();
	}


	/**
	 * Clears game map state information
	 */
	public void clearMap() {
		for (int row = 0; row < rows; row++) {
			for (int col = 0; col < cols; col++) {
				if (map[row][col] != Ilk.WATER) {
					map[row][col] = Ilk.LAND;
				}
			}
		}
		this.visionMatrix = null;
	}
	public boolean isVisible(Tile location) {
		if (this.visionMatrix == null) {
			if (this.visionOffsets2 == null) {
				int mx = (int)(Math.sqrt(this.viewRadius2));
				this.visionOffsets2 = new int[2*mx+1][2];
				for (int dRow = -mx; dRow <= mx; dRow++) {
					for (int dCol = -mx; dCol <= mx; dCol++) {
						int d = dRow*dRow + dCol*dCol;
						if (d <= this.viewRadius2) {
							this.visionOffsets2[mx][0] = dRow % getRows() - getRows();
							this.visionOffsets2[mx][1] = dCol % getCols() - getCols();
						}
					}
				}
			}
			
			this.visionMatrix = new boolean[getRows()][getCols()];
			for (int r = 0; r < getRows(); r++) {
				for (int c = 0; c < getCols(); c++) {
					this.visionMatrix[r][c] = false;
				}
			}

			for (Tile ant : getMyAnts()) {
				for (int i = 0; i < this.visionOffsets2.length; i++) {
					int vRow = (this.visionOffsets2[i][0] + ant.getRow()) % rows;
					if (vRow < 0) {
						vRow += rows;
					}
					int vCol = (this.visionOffsets2[i][1] + ant.getCol()) % cols;
					if (vCol < 0) {
						vCol += cols;
					}

					this.visionMatrix[vRow][vCol] = true;
				}
			}
		}
		return this.visionMatrix[location.getRow()][location.getCol()];
	}
	
	/**
	 * Updates game state information about new ants and food locations.
	 * 
	 * @param ilk ilk to be updated
	 * @param tile location on the game map to be updated
	 */
	public void update(Ilk ilk, Tile tile) {
		map[tile.getRow()][tile.getCol()] = ilk;
		switch (ilk) {
			case FOOD:
				foodTiles.add(tile);
				break;
			case MY_ANT:
				myAnts.add(tile);
				break;
			case ENEMY_ANT:
				enemyAnts.add(tile);
				break;
		}
	}
	public LinkedList<Node> findPath(Tile start, Tile end) {
		HashSet<Node> frontier = new HashSet<Node>();
		frontier.add(new Node(this, start, null, end));
		HashSet<Node> explored = new HashSet<Node>();

		while (frontier.size() > 0) {
			int min = 999999;
			Node current = (Node)frontier.toArray()[0];
			for (Node node : frontier) {
				if (node.value() < min) {
					current = node;
					min = node.value();
				}
			}
			frontier.remove(current);
			explored.add(current);


			//Logger.getAnonymousLogger().warning("current: " + current.position + " , dest: " + end);
			if (current.position.getRow() == end.getRow() && current.position.getCol() == end.getCol()) {
				//Logger.getAnonymousLogger().warning("here we go");
				return current.getPath();
			} else if (frontier.size() > 100) {
				for (Node n : frontier) {
					if (n.value() < current.value()) {
						current = n;
					}
				}
				return current.getPath();
			}

			for (Tile neighbor : current.getNeighbors()) {
				if (!frontier.contains(neighbor) && !explored.contains(neighbor)) {
					frontier.add(new Node(this, neighbor, current, end));
				}
			}
		}

		return new LinkedList<Node>();
	}

	public LinkedList<Node> bestFirstSearch(Tile start, Tile end) {
		HashSet<Node> open = new HashSet<Node>();
		open.add(new Node(this, start, null, end));
		HashSet<Node> closed = new HashSet<Node>();

		while (open.size() > 0) {
			//Logger.getAnonymousLogger().warning("frontier size: " + open.size());
			Node bestNode = null;
			for (Node n : open) {
				bestNode = n;
				break;
			}
			for (Node n : open) {
				if (n.value() < bestNode.value()) {
					bestNode = n;
				}
			}
			open.remove(bestNode);
			closed.add(bestNode);
			if (bestNode.position.getRow() == end.getRow() && bestNode.position.getCol() == end.getCol()) {
				return bestNode.getPath();
			} else if (open.size() > 100) {
				for (Node n : open) {
					if (n.value() < bestNode.value()) {
						bestNode = n;
					}
				}
				return bestNode.getPath();
			}

	
			for (Tile neighbor : bestNode.getNeighbors()) {
				boolean seen = false;
				for (Node n : closed) {
					if (n.position.getRow() == neighbor.getRow() && n.position.getCol() == neighbor.getCol()) {
						seen = true;
						if (bestNode.getPath().size() < n.getPath().size()) {
							n.parent = bestNode;
						}
					}
				}
				if (!seen) {
					open.add(new Node(this, neighbor, bestNode, end));
				} 
			}
		}
		return new LinkedList<Node>();
	}

	public List<Aim> pathDirections(Tile start, Tile end) {
		//Logger.getAnonymousLogger().warning("ant at " + start + " wants to go to " + end);
		LinkedList<Node> path = bestFirstSearch(start, end);
		for (Node node : path) {
			if (node.parent != null && node.parent.position == start) {
				List<Aim> directions = getDirections(node.parent.position, node.position);
				//Logger.getAnonymousLogger().warning("therefore the ant goes " + directions.toString() + " to " + node.position);
				return directions;
			}
		}
		return getDirections(start, end);
	}


	/**
	 * Updates game state information about hills locations.
	 *
	 * @param owner owner of hill
	 * @param tile location on the game map to be updated
	 */
	public void updateHills(int owner, Tile tile) {
		if (owner > 0)
			enemyHills.add(tile);
		else
			myHills.add(tile);
	}

	/**
	 * Issues an order by sending it to the system output.
	 * 
	 * @param myAnt map tile with my ant
	 * @param direction direction in which to move my ant
	 */
	public void issueOrder(Tile myAnt, Aim direction) {
		Order order = new Order(myAnt, direction);
		orders.add(order);
		System.out.println(order);
	}
}
