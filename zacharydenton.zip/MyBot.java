import java.util.*;
import java.io.IOException;
import java.util.logging.*;

/**
 * Starter bot implementation.
 */
public class MyBot extends Bot {
	/**
	 * Main method executed by the game engine for starting the bot.
	 * 
	 * @param args command line arguments
	 * 
	 * @throws IOException if an I/O error occurs
	 */
	public static void main(String[] args) throws IOException {
		new MyBot().readSystemInput();
	}

	private ArrayList<Tile> unseen;

	public void setup(int loadTime, int turnTime, int rows, int cols, int turns, int viewRadius2,
			int attackRadius2, int spawnRadius2) {
		setAnts(new Ants(loadTime, turnTime, rows, cols, turns, viewRadius2, attackRadius2,
					spawnRadius2));
		unseen = new ArrayList<Tile>();
		for (int r = 0; r < getAnts().getRows(); r++) {
			for (int c = 0; c < getAnts().getCols(); c++) {
				unseen.add(new Tile(r, c));
			}
		}
	}

	public boolean moveDirection(Ants ants, Set<Tile> destinations, Tile location, Aim direction) {
		Tile destination = ants.getTile(location, direction);
		if (ants.getIlk(destination).isUnoccupied() && !destinations.contains(destination)) {
			ants.issueOrder(location, direction);
			destinations.add(destination);
			return true;
		} else {
			return false;
		}
	}

	public void assignTargets(Ants ants, Set<Tile> destinations, Set<Tile> goals, Set<Tile> active, Set<Tile> targets) {
		for (Tile target : targets) {
			Tile closestAnt = null;
			int closestDistance = 999999;
			for (Tile ant : ants.getMyAnts()) {
				if (!active.contains(ant)) {
					int distance = ants.getDistance(ant, target);
					if (distance < closestDistance) {
						closestDistance = distance;
						closestAnt = ant;
					}
				}
			}
			if (closestAnt != null) {
				//List<Aim> directions = ants.getDirections(closestAnt, target);
				List<Aim> directions = ants.pathDirections(closestAnt, target);
				Collections.shuffle(directions);
				for (Aim direction : directions) {
					if (moveDirection(ants, destinations, closestAnt, direction)) {
						goals.add(target);
						active.add(closestAnt);
					}
				}
			}
		}
		for (Tile ant : ants.getMyAnts()) {
			if (!active.contains(ant)) {
				destinations.add(ant);
			}
		}
	}

	public Set<Tile> getRandomExplorationTargets(Ants ants, int numTargets) {
		HashSet<Tile> targets = new HashSet<Tile>();
		for (int i = 0; i < numTargets; i++) {
			int row = (int)(Math.random() * (ants.getRows() + 1));
			int col = (int)(Math.random() * (ants.getCols() + 1));
			Tile target = new Tile(row, col);
			while (!unseen.contains(target)) {
				row = (int)(Math.random() * (ants.getRows() + 1));
				col = (int)(Math.random() * (ants.getCols() + 1));
				target = new Tile(row, col);
			}
			targets.add(target);
		}
		return targets;
	}

	public Set<Tile> getExplorationTargets(Ants ants, int numTargets) {
		HashSet<Tile> targets = new HashSet<Tile>();
		for (int i = 0; i < numTargets; i++) {
			targets.add(unseen.get(i));
		}
		return targets;
	}

	public int numAllies(Ants ants, Tile ant, int radius) {
		int count = 0;
		for (Tile otherAnt : ants.getMyAnts()) {
			if (ant == otherAnt)
				continue;
			if (ants.getDistance(ant, otherAnt) <= radius) {
				Logger.getAnonymousLogger().warning("ant at " + ant + " is allied with ant at " + otherAnt);
				count++;
			}
		}
		return count;
	}

	public void gatherFood(Ants ants, Set<Tile> destinations, Set<Tile> goals, Set<Tile> active) {
		assignTargets(ants, destinations, goals, active, ants.getFoodTiles());
	}

	public void exploreMap(Ants ants, Set<Tile> destinations, Set<Tile> goals, Set<Tile> active) {
		assignTargets(ants, destinations, goals, active, 
				getExplorationTargets(ants, ants.getMyAnts().size() - active.size()));
	}

	public void attackEnemyAnts(Ants ants, Set<Tile> destinations, Set<Tile> goals, Set<Tile> active) {
		assignTargets(ants, destinations, goals, active, ants.getEnemyAnts());
	}

	public void attackEnemyHills(Ants ants, Set<Tile> destinations, Set<Tile> goals, Set<Tile> active) {
		assignTargets(ants, destinations, goals, active, ants.getEnemyHills());
	}

	public void findAllies(Ants ants, Set<Tile> destinations, Set<Tile> goals, Set<Tile> active) {
		Set<Tile> unallied = new HashSet<Tile>();
		for (Tile ant : ants.getMyAnts()) {
			if (numAllies(ants, ant, 1) == 0) {
				unallied.add(ant);
			}
		}
		Logger.getAnonymousLogger().warning(unallied.toString());
		assignTargets(ants, destinations, goals, active, unallied);
	}

	public void doTurn() {
		Ants ants = getAnts();
		Set<Tile> destinations = new HashSet<Tile>();
		Set<Tile> goals = new HashSet<Tile>();
		Set<Tile> active = new HashSet<Tile>();

		for (Tile ant : ants.getMyAnts()) {
			if (goals.contains(ant)) {
				goals.remove(ant);
			}
		}

		ArrayList<Tile> oldUnseen = new ArrayList<Tile>(unseen);
		for (Tile location : oldUnseen) {
			if (ants.isVisible(location)) {
				unseen.remove(location);
			}
		}

		if (ants.getMyAnts().size() < 50) {
			gatherFood(ants, destinations, goals, active);
		} else {
			attackEnemyHills(ants, destinations, goals, active);
			//findAllies(ants, destinations, goals, active);
			attackEnemyAnts(ants, destinations, goals, active);
		}
		gatherFood(ants, destinations, goals, active);
		exploreMap(ants, destinations, goals, active);
	}
}
